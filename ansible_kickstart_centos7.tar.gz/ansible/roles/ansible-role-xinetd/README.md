Ansible Role: xinetd
=========

Requirements
------------

None.

Role Variables
--------------

None.

Dependencies
------------

None.

Example Playbook
----------------

    - hosts: servers
      roles:
         - { role: shomatan.xinetd }

License
-------

BSD

Author Information
------------------

Shoma Nishitateno (shoma416@gmail.com)
